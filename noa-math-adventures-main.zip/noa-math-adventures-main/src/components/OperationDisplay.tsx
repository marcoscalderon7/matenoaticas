
import React from 'react';

interface OperationDisplayProps {
  operation: string;
}

const OperationDisplay: React.FC<OperationDisplayProps> = ({ operation }) => {
  return (
    <div className="absolute top-4 left-4 sm:top-8 sm:left-8 bg-soft-yellow p-3 sm:p-4 border-2 border-black shadow-md">
      <p className="font-pixel text-xl sm:text-2xl text-black select-none">{operation}</p>
    </div>
  );
};

export default OperationDisplay;
