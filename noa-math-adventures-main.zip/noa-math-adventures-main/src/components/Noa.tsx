
import React from 'react';

interface NoaProps {
  position: { x: number; y: number };
  // isFalling: boolean; // This prop might be less relevant if the image is static
  showParachute: boolean; // We'll keep this, GameScreen uses it to signify landing
}

const Noa: React.FC<NoaProps> = ({ position }) => {
  return (
    <div
      className="absolute transition-transform duration-100 ease-linear"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        transform: 'translateX(-50%)', // Center Noa horizontally
      }}
    >
      {/* The new image replaces the old Noa visuals.
          We assume the image includes the parachute.
          The showParachute prop logic is mainly handled in GameScreen for game state.
      */}
      <img
        src="/lovable-uploads/9e249a35-79f0-44fe-a004-bfccef42d4d1.png"
        alt="Noa"
        className="w-16 h-auto select-none" // Approx 64px width, height will scale.
        style={{ imageRendering: 'pixelated' }}
      />
    </div>
  );
};

export default Noa;
