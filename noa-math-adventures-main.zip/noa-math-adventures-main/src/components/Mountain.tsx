import React from 'react';

interface MountainProps {
  id: number;
  value: number;
  positionX: number; // Percentage from left
}

const Mountain: React.FC<MountainProps> = ({ value, positionX }) => {
  return (
    <div
      className="absolute bottom-0 flex flex-col items-center"
      style={{
        left: `${positionX}%`,
        transform: 'translateX(-50%)', // Center mountain
        imageRendering: 'pixelated',
      }}
    >
      {/* Changed to a square with rounded corners, keeping responsive sizing */}
      <div 
        className="w-20 h-20 sm:w-24 sm:h-24 md:w-24 md:h-24 bg-game-red border-2 border-black rounded-md flex items-center justify-center"
      >
        <span className="font-pixel text-xl sm:text-2xl text-white select-none">{value}</span>
      </div>
      {/* Base removed as it's not suitable for a square shape */}
    </div>
  );
};

export default Mountain;
