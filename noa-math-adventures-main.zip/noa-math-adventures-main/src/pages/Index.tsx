
import { Navigate } from 'react-router-dom';

// This page will now redirect to the StartScreen by default.
// Or it could be a landing page if the game becomes part of a larger site.
const Index = () => {
  return <Navigate to="/" replace />;
};

export default Index;
