
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button'; // Using shadcn button for now, can be styled further

const StartScreen: React.FC = () => {
  const navigate = useNavigate();

  const startGame = () => {
    navigate('/game');
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-soft-blue">
      <h1 className="font-pixel text-5xl sm:text-6xl md:text-7xl text-primary-purple mb-12 text-center" style={{ WebkitTextStroke: '2px black', textShadow: '4px 4px 0px #000000b0' }}>
        mateNOAticas
      </h1>
      <div className="space-y-6">
        <button onClick={startGame} className="pixel-button text-2xl w-64">
          Start
        </button>
        {/* <Button variant="outline" className="pixel-button text-2xl w-64 opacity-50 cursor-not-allowed" disabled>
          Configuración
        </Button> */}
      </div>
      <p className="font-pixel text-xs text-neutral-gray absolute bottom-4">
        © {new Date().getFullYear()} mateNOAticas Team
      </p>
    </div>
  );
};

export default StartScreen;
