
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Noa from '@/components/Noa';
import Mountain from '@/components/Mountain';
import OperationDisplay from '@/components/OperationDisplay';
import { generateSumProblem, MathProblem } from '@/lib/mathUtils';
import { playWinSound, playLoseSound } from '@/lib/soundUtils';
import { Button } from '@/components/ui/button';
import { toast } from "sonner"
import { ArrowLeft, CheckCircle, XCircle } from 'lucide-react';

// const GAME_WIDTH = 800; // This is now dynamic via gameAreaWidth
const NOA_SPEED = 20;
const FALL_SPEED = 3;
const FALL_INTERVAL = 50;

// Updated dimensions based on new asset sizes
const NEW_MOUNTAIN_HEIGHT_PX = 96; // md:h-24 (24 * 4px) - remains the same
const NEW_MOUNTAIN_WIDTH_PX = 96;  // md:w-24 (24 * 4px) - updated for square mountain
const NOA_IMAGE_WIDTH_PX = 64;    // w-16 (16 * 4px)
const NOA_IMAGE_HEIGHT_PX = 102;  // Approximate height for w-16 with aspect ratio of uploaded image

type GameState = 'idle' | 'falling' | 'answeredCorrectly' | 'answeredIncorrectly' | 'gameOver';

const GameScreen: React.FC = () => {
  const navigate = useNavigate();
  const [problem, setProblem] = useState<MathProblem>(generateSumProblem());
  const [noaPosition, setNoaPosition] = useState({ x: 400, y: -100 }); // Initial x based on typical game width
  const [gameState, setGameState] = useState<GameState>('idle');
  const [showParachute, setShowParachute] = useState(true); // GameScreen controls this state
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const [gameAreaWidth, setGameAreaWidth] = useState(800); // Default, will update

  useEffect(() => {
    const updateGameAreaWidth = () => {
      if (gameAreaRef.current) {
        const currentWidth = gameAreaRef.current.offsetWidth;
        setGameAreaWidth(currentWidth);
        if (gameState === 'idle' || noaPosition.y < 0) { // Reset Noa's horizontal position if idle or off-screen
             setNoaPosition(prev => ({ ...prev, x: currentWidth / 2 }));
        }
      }
    };
    updateGameAreaWidth(); // Initial call
    window.addEventListener('resize', updateGameAreaWidth);
    return () => window.removeEventListener('resize', updateGameAreaWidth);
  }, [gameState, noaPosition.y]);


  const startLevel = useCallback(() => {
    setProblem(generateSumProblem());
    // Start Noa at top-center of the current game area
    setNoaPosition({ x: gameAreaWidth / 2, y: 0 });
    setShowParachute(true); // Noa starts with parachute
    setGameState('falling');
  }, [gameAreaWidth]);

  useEffect(() => {
    if (gameState === 'idle') {
      toast("Presiona Enter o haz clic en 'Iniciar Caída' para comenzar.", {
        duration: 5000,
      });
    }
  }, [gameState]);


  useEffect(() => {
    let fallIntervalId: NodeJS.Timeout;
    if (gameState === 'falling') {
      fallIntervalId = setInterval(() => {
        setNoaPosition(prevPos => {
          const newY = prevPos.y + FALL_SPEED;
          const gameAreaHeight = gameAreaRef.current?.offsetHeight || 600;

          // Check for landing using new dimensions
          // Noa lands when her image's bottom touches the mountain top
          const noaBottomEdge = newY + NOA_IMAGE_HEIGHT_PX;
          const mountainTopEdge = gameAreaHeight - NEW_MOUNTAIN_HEIGHT_PX;

          if (noaBottomEdge >= mountainTopEdge) {
            clearInterval(fallIntervalId);
            setShowParachute(false); // Logically, parachute is "off" when landed

            let landedMountainValue: number | null = null;
            const mountainPositionsX = [25, 50, 75]; // percentages

            for (let i = 0; i < problem.options.length; i++) {
              const mountainCenterX = (mountainPositionsX[i] / 100) * gameAreaWidth;
              const noaCenterX = prevPos.x; // Noa's position is already her center due to translateX(-50%)

              // Check if Noa's center is within half of the mountain's width
              // NEW_MOUNTAIN_WIDTH_PX has been updated to 96
              if (Math.abs(noaCenterX - mountainCenterX) < NEW_MOUNTAIN_WIDTH_PX / 2) {
                landedMountainValue = problem.options[i];
                break;
              }
            }

            if (landedMountainValue === problem.correctAnswer) {
              setGameState('answeredCorrectly');
              toast.success("¡Correcto! 🎉", { icon: <CheckCircle className="text-green-500" /> });
              playWinSound();
            } else {
              setGameState('answeredIncorrectly');
              toast.error("¡Oh no! Intenta de nuevo. 🎈", { icon: <XCircle className="text-red-500" /> });
              playLoseSound();
            }
            // Snap Noa to the landing position: her bottom edge aligns with mountain top edge
            return { ...prevPos, y: mountainTopEdge - NOA_IMAGE_HEIGHT_PX };
          }
          return { ...prevPos, y: newY };
        });
      }, FALL_INTERVAL);
    }
    return () => clearInterval(fallIntervalId);
  }, [gameState, problem.options, problem.correctAnswer, gameAreaWidth, gameAreaRef]);

  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (gameState === 'falling') {
      setNoaPosition(prevPos => {
        let newX = prevPos.x;
        const noaHalfWidth = NOA_IMAGE_WIDTH_PX / 2;
        if (event.key === 'ArrowLeft') {
          newX = Math.max(noaHalfWidth, prevPos.x - NOA_SPEED);
        } else if (event.key === 'ArrowRight') {
          newX = Math.min(gameAreaWidth - noaHalfWidth, prevPos.x + NOA_SPEED);
        }
        return { ...prevPos, x: newX };
      });
    } else if (gameState === 'idle' && event.key === 'Enter') {
      startLevel();
    } else if ((gameState === 'answeredCorrectly' || gameState === 'answeredIncorrectly') && event.key === 'Enter') {
      startLevel();
    }
  }, [gameState, startLevel, gameAreaWidth]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);

  const mountainPositionsX = [25, 50, 75];

  return (
    <div ref={gameAreaRef} className="w-full max-w-3xl h-[600px] bg-soft-blue relative overflow-hidden border-4 border-black shadow-2xl mx-auto my-4" style={{ imageRendering: 'pixelated' }}>
      <OperationDisplay operation={problem.question} />
      <Noa position={noaPosition} showParachute={showParachute} />
      
      {problem.options.map((option, index) => (
        <Mountain key={index} id={index} value={option} positionX={mountainPositionsX[index]} />
      ))}

      {gameState === 'idle' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-50">
          <p className="font-pixel text-3xl text-white mb-6">Nivel 1: Sumas</p>
          <button onClick={startLevel} className="pixel-button">
            Iniciar Caída (Enter)
          </button>
        </div>
      )}

      {(gameState === 'answeredCorrectly' || gameState === 'answeredIncorrectly') && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-50">
          <p className={`font-pixel text-4xl mb-6 ${gameState === 'answeredCorrectly' ? 'text-green-400' : 'text-game-red'}`}>
            {gameState === 'answeredCorrectly' ? '¡GENIAL!' : '¡UPS!'}
          </p>
          {gameState === 'answeredCorrectly' && (
            <div className="text-6xl animate-fireworks-burst">✨</div>
          )}
          <button onClick={startLevel} className="pixel-button mt-4">
            Siguiente (Enter)
          </button>
        </div>
      )}
       <Button onClick={() => navigate('/')} variant="outline" className="absolute bottom-4 left-4 font-pixel text-xs">
        <ArrowLeft className="mr-1 h-3 w-3"/> Salir
      </Button>
    </div>
  );
};

export default GameScreen;
