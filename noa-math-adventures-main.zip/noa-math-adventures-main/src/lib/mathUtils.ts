
export interface MathProblem {
  operand1: number;
  operand2: number;
  operator: '+' | '-' | '×' | '÷';
  question: string;
  correctAnswer: number;
  options: number[];
}

const generateRandomNumber = (min: number, max: number): number => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

export const generateSumProblem = (maxSum: number = 50): MathProblem => {
  const operand1 = generateRandomNumber(1, maxSum - 1);
  const operand2 = generateRandomNumber(1, maxSum - operand1);
  const correctAnswer = operand1 + operand2;
  const question = `${operand1} + ${operand2} = ?`;

  const options = generateOptions(correctAnswer);

  return { operand1, operand2, operator: '+', question, correctAnswer, options };
};

// Generates 2 incorrect options alongside the correct one
const generateOptions = (correctAnswer: number): number[] => {
  const options: Set<number> = new Set();
  options.add(correctAnswer);

  while (options.size < 3) {
    const range = Math.max(10, correctAnswer); // Ensure some variance for small answers
    const randomOffset = generateRandomNumber(-Math.floor(range/2) , Math.floor(range/2));
    let incorrectOption = correctAnswer + randomOffset;
    if (incorrectOption <= 0) incorrectOption = generateRandomNumber(1,10); // Ensure positive options
    if (incorrectOption !== correctAnswer) {
      options.add(incorrectOption);
    }
  }
  // Shuffle options
  return Array.from(options).sort(() => Math.random() - 0.5);
};

// We will add generateSubtractionProblem, generateMultiplicationProblem, generateDivisionProblem later.
