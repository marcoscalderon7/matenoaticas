
// Utility functions for playing sounds

export const playWinSound = () => {
  // IMPORTANT: Create a 'public/sounds' folder and add 'win-sound.mp3'
  const audio = new Audio('/sounds/win-sound.mp3');
  audio.play().catch(e => console.error("Error playing win sound:", e));
};

export const playLoseSound = () => {
  // IMPORTANT: Create a 'public/sounds' folder and add 'lose-sound.mp3'
  const audio = new Audio('/sounds/lose-sound.mp3');
  audio.play().catch(e => console.error("Error playing lose sound:", e));
};
